/*
 * Copyright (c) 2021 Randall Rowland
 */

typeSearchIndex = [{"l":"All Classes","u":"allclasses-index.html"},{"p":"<Unnamed>","l":"Appointment"},{"p":"<Unnamed>","l":"AppointmentService"},{"p":"<Unnamed>","l":"Contact"},{"p":"<Unnamed>","l":"ContactService"},{"p":"<Unnamed>","l":"ContactServiceTest"},{"p":"<Unnamed>","l":"ContactTest"},{"p":"<Unnamed>","l":"Task"},{"p":"<Unnamed>","l":"TaskService"}];updateSearchResults();